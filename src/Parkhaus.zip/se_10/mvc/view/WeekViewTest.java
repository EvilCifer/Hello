package se_10.mvc.view;

import static org.junit.Assert.*;

import org.junit.Test;

public class WeekViewTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
