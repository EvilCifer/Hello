package se_10.mvc.controller;

public class MainController {

	public static void main(String[] args) {
		CarParkController.getInstance();
	}
}
