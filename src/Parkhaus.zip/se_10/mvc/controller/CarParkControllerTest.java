package se_10.mvc.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class CarParkControllerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
